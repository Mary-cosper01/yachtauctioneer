
Hi, New Application
Name : {{$name}}
Email : {{$email}}
Number : {{$number}}
@if($requirement!='')
Requirement : {{$requirement}}
@endif
@if($service!='')
Service : {{$service}}
@endif
<!--Sending Mail from hmwriterspro.-->