@include('layout.header')

<body>
    <div id="loader-wrapper">
      <div id="loader"></div>
    </div>
    <div id="page" class="page">
        @include('layout.nav')
        @yield('content')
    </div>

    @include('layout.footer')
    

</body>
</html>